
class LoginScreen extends Screen {   
    static Name = 'Login screen' 
    static Id = 'login-screen';
    static Template = '';

    constructor(){    
        super();
    }

    SwitchTo(){
        let myElem = document.querySelector('#SwitchToRegister');
        myElem.addEventListener('click', ()=>{   
            Navigator.navigate("register"); 
        }); 
    }

}

app.screens['login'] = LoginScreen; 

