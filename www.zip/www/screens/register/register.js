
class RegisterScreen extends Screen {
    static Name = 'Register screen'
    static Id = 'register-screen';
    static Template = '';  

    constructor(){
        super();
    }

    SwitchTo(){
        let myElem = document.querySelector('#SwitchToLogIn');
        console.log(myElem);
        myElem.addEventListener('click', ()=>{
            Navigator.navigate("login");
        });
    }
}

app.screens['register'] =RegisterScreen;